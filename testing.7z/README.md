## Практика по предмету "Автоматизированное тестирование"

Запустить тесты и сгенерировать отчет - `mvn clean test site`

Отчет будет находиться в папке `target/site/allure-maven-plugin`

Чтобы его открыть, необходимо запустить команду `io.qameta.allure:allure-maven:serve`

